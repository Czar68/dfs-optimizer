#!/usr/bin/env python3
"""Generate .htpasswd for DFS Optimizer (Windows or Linux).

Usage:
  python ionos-deploy/htpasswd-generate.py
  python ionos-deploy/htpasswd-generate.py YourPassword123

Writes ionos-deploy/.htpasswd with user 'dfs-opt'. Use SHA512 (Apache 2.4+).
"""
import getpass
import os
import sys

USER = "dfs-opt"
SCRIPT_DIR = os.path.dirname(os.path.abspath(__file__))
OUTPUT = os.path.join(SCRIPT_DIR, ".htpasswd")


def gen_hash(password: str) -> str:
    try:
        import crypt
        salt = crypt.mksalt(crypt.METHOD_SHA512)
        return crypt.crypt(password, salt)
    except (ImportError, AttributeError):
        pass
    try:
        from passlib.hash import sha512_crypt
        return sha512_crypt.hash(password, rounds=656000)
    except ImportError:
        pass
    sys.stderr.write(
        "Need 'crypt' (Unix) or 'passlib'. On Windows: pip install passlib\n"
    )
    sys.exit(1)


def main():
    if len(sys.argv) >= 2:
        password = sys.argv[1]
    else:
        password = getpass.getpass("Password for dfs-opt: ")
    if not password:
        sys.stderr.write("Empty password not allowed.\n")
        sys.exit(1)
    h = gen_hash(password)
    line = USER + ":" + h + "\n"
    with open(OUTPUT, "w", encoding="utf-8") as f:
        f.write(line)
    print("Wrote " + OUTPUT)
    print("Upload this file to your IONOS document root.")


if __name__ == "__main__":
    main()
