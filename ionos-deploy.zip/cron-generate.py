#!/usr/bin/env python3
"""IONOS Cron Job: Run optimizer + push results to Google Sheets.

Schedule (all times EST / America/New_York):
  7:00 AM  — Morning slate (early games, overnight line moves)
  12:00 PM — Noon refresh (afternoon games lock ~1pm)
  6:00 PM  — Evening slate (primetime NBA games lock 7-7:30pm)
  2:00 AM  — Final results (all games finished, capture final data)

IONOS cron (server runs UTC — EST = UTC-5, EDT = UTC-4):
  Standard Time (Nov-Mar): 0 12,17,23,7 * * *
  Daylight Time (Mar-Nov): 0 11,16,22,6 * * *

  Or use a single entry that covers both (runs at both offsets; one is a no-op):
  0 6,7,11,12,16,17,22,23 * * *  cd /homepages/htdocs && python3 cron-generate.py >> cron.log 2>&1

  The script checks the current EST hour and only runs at the 4 target windows.
"""
import os
import subprocess
import sys
from datetime import datetime, timezone, timedelta

PROJECT_DIR = os.path.dirname(os.path.abspath(__file__))

EST = timezone(timedelta(hours=-5))
TARGET_HOURS_EST = {7, 12, 18, 2}


def est_now():
    return datetime.now(EST)


def log(msg):
    ts = est_now().strftime("%Y-%m-%d %H:%M:%S ET")
    print(f"[{ts}] {msg}")


def run(cmd, label):
    log(f"Starting: {label}")
    result = subprocess.run(
        cmd, cwd=PROJECT_DIR, shell=True,
        capture_output=True, text=True, timeout=900
    )
    if result.stdout:
        print(result.stdout[-3000:])
    if result.returncode != 0:
        log(f"FAILED ({label}): exit {result.returncode}")
        if result.stderr:
            print(result.stderr[-1500:])
        return False
    log(f"OK: {label}")
    return True


def run_label():
    h = est_now().hour
    labels = {2: "2AM Final Results", 7: "7AM Morning", 12: "Noon", 18: "6PM Evening"}
    return labels.get(h, f"{h}:00")


if __name__ == "__main__":
    now = est_now()
    hour = now.hour

    if hour not in TARGET_HOURS_EST:
        print(f"[{now.strftime('%Y-%m-%d %H:%M ET')}] Not a target run hour ({hour}:00 ET). Target: {sorted(TARGET_HOURS_EST)}. Exiting.")
        sys.exit(0)

    label = run_label()
    print(f"\n{'='*60}")
    log(f"=== PRODUCTION RUN: {label} ===")
    print(f"{'='*60}")

    is_results_run = (hour == 2)

    ok = run("npm run generate:production", f"Optimizer PP + UD ({label})")
    if not ok and not is_results_run:
        log("Optimizer failed — skipping sheets push")
        sys.exit(1)

    run("python3 sheets_setup_9tab.py", "Sheets setup (headers + formatting)")
    run("python3 sheets_push_cards.py", "Sheets push (cards)")

    log(f"=== {label} COMPLETE ===\n")
