#!/usr/bin/env python3
"""Post-upload verification for IONOS deploy. Run on server after extracting ionos-deploy.zip.

  python3 verify.py

Exits 0 if all checks pass, 1 otherwise.
"""
import os
import sys

REQUIRED = [
    "index.html",
    ".htaccess",
    "cron-generate.py",
    "package.json",
]

OPTIONAL = [
    "assets",
    "dist",
    "scripts",
    "credentials.json",
    "token.json",
    ".htpasswd",
]

def main():
    base = os.path.dirname(os.path.abspath(__file__))
    os.chdir(base)
    missing = []
    for name in REQUIRED:
        path = os.path.join(base, name)
        if not os.path.exists(path):
            missing.append(name)
        else:
            kind = "dir" if os.path.isdir(path) else "file"
            print(f"  OK  {name} ({kind})")
    for name in OPTIONAL:
        path = os.path.join(base, name)
        if os.path.exists(path):
            kind = "dir" if os.path.isdir(path) else "file"
            print(f"  OK  {name} ({kind})")
        else:
            print(f"  --  {name} (optional, missing)")
    if missing:
        print("\nMISSING REQUIRED:", ", ".join(missing))
        sys.exit(1)
    print("\nVerify OK — deploy structure looks good.")
    sys.exit(0)

if __name__ == "__main__":
    main()
