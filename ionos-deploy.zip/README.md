# IONOS Production Deploy — DFS Optimizer

## IONOS WebHosting — Exact Steps

**Panel:** https://my.ionos.com/webhosting/b300099b-8c82-46cc-9e4b-250f6f70609b

### 1. File Management → Document Root (`/`)

- Upload **all contents** of `ionos-deploy/` (files and folders).
- Do **not** upload the `ionos-deploy` folder itself — upload what’s **inside** it into the document root.

### 2. Generate and upload `.htpasswd`

**Option A — Python (Windows or Linux):**

```bash
cd ionos-deploy
python htpasswd-generate.py
# Enter your password when prompted. Then upload the created .htpasswd to document root.
```

**Option B — Apache htpasswd (Git Bash / WSL):**

```bash
htpasswd -cb .htpasswd dfs-opt YourPassword123
```

Upload `.htpasswd` to the same directory as `.htaccess` (document root).

### 3. Cron Jobs → Add job

In IONOS WebHosting → **Cron Jobs** → Add:

```bash
0 6,7,11,12,16,17,22,23 * * * cd /homepages/htdocs && python3 cron-generate.py >> cron.log 2>&1
```

The script checks the current EST hour and only runs at the 4 target windows:
- **7:00 AM ET** — Morning slate (overnight line moves)
- **12:00 PM ET** — Noon refresh (afternoon games)
- **6:00 PM ET** — Evening slate (primetime games)
- **2:00 AM ET** — Final results (all games finished)

The doubled UTC hours handle EST vs EDT automatically.

### 4. Test

- **URL:** https://gamesmoviesmusic.com  
- **Username:** `dfs-opt`  
- **Password:** [the password you set in .htpasswd]

After login you should see the live Props Kelly Dashboard.

### 5. Validate cron (optional)

On the server (SSH or IONOS “Execute script” if available), run:

```bash
chmod +x test.sh
./test.sh
```

Or manually:

```bash
curl -I https://gamesmoviesmusic.com
tail -20 cron.log
python3 cron-generate.py
```

---

## Local build (before upload)

```cmd
cd dfs-optimizer
deploy.bat
```

This runs the optimizer, builds the dashboard, and stages everything into `ionos-deploy/`.

---

## File inventory

| File | Purpose |
|------|---------|
| `index.html` + `assets/` | Vite-built React dashboard |
| `.htaccess` | Basic auth, HTTPS redirect, SPA routing |
| `.htpasswd` | Username/password (generate with `htpasswd-generate.py`) |
| `cron-generate.py` | Cron entry: optimizer + sheets push |
| `test.sh` | Production test: curl, tail cron.log, run cron |
| `htpasswd-generate.py` | Creates `.htpasswd` from password (Windows/Linux) |
| `sheets_setup_9tab.py` | Google Sheets tab setup + formatting |
| `sheets_push_cards.py` | Push card data to Sheets |
| `sheets_push_legs.py` | Push leg data to Sheets |
| `sheets_push_underdog_legs.py` | Push UD leg data |
| `sheets_push_underdog_cards.py` | Push UD card data |
| `credentials.json` / `token.json` | Google OAuth (do not expose publicly) |

---

## Security

- `.htaccess` applies Basic auth to all routes and forces HTTPS.
- Keep `credentials.json` and `token.json` out of public URLs (IONOS often hides dotfiles; verify).
- Rotate your Google OAuth token periodically.

---

## Troubleshooting

- **401 / wrong password:** Regenerate `.htpasswd` with `htpasswd-generate.py` and re-upload.
- **502 on cron:** Ensure Node/npm and Python are in cron’s PATH; use full paths if needed.
- **Sheets auth fails:** Re-upload `token.json` (tokens can expire; re-auth locally if needed).
- **Dashboard blank:** Confirm `index.html` and `assets/` are in document root.
- **SPA routes 404:** Ensure `.htaccess` and `RewriteEngine` are enabled.

---

## Telegram (optional)

To get alerts (e.g. low card count, Sheets push failure) and optional top-5 card pushes:

1. **Local:** Keep `TELEGRAM_BOT_TOKEN` and `TELEGRAM_CHAT_ID` in `.env` (already gitignored). Copy from `.env.example` and fill in your values.
2. **IONOS:** On the server, create or edit `.env` in the document root and add:
   ```bash
   TELEGRAM_BOT_TOKEN=your_token_from_botfather
   TELEGRAM_CHAT_ID=your_chat_or_channel_id
   ```
   Do **not** commit or paste the token in the repo or README. Load `.env` in cron if your cron runner doesn’t load it automatically (e.g. `set -a; source .env; set +a` before `python3 cron-generate.py`).
3. **Run with Telegram:** Use `--telegram` when running the optimizer (e.g. in `cron-generate.py` add `--telegram` to the `generate:production` command if you want Telegram alerts from the cron run).
