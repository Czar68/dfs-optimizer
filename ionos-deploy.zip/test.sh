#!/bin/bash
# Production test script — run on IONOS (SSH) or locally to validate deploy.
# Usage: ./test.sh   or   bash test.sh

set -e
cd "$(dirname "$0")"
echo "=== IONOS PRODUCTION TEST ==="
echo ""

echo "1. HTTP(S) check:"
curl -sI "https://gamesmoviesmusic.com" | head -5
echo ""

echo "2. Last 20 lines of cron.log (if present):"
if [ -f cron.log ]; then
  tail -20 cron.log
else
  echo "  (cron.log not found — cron may not have run yet)"
fi
echo ""

echo "3. Run cron-generate.py (dry validation):"
python3 cron-generate.py
echo ""
echo "=== TEST DONE ==="
