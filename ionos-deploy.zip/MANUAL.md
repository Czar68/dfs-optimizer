# IONOS Manual Deploy — ZIP Upload (Folder Bypass)

**Why ZIP?** IONOS File Management often uploads folders as 0-byte placeholders. Uploading a ZIP and extracting on the server preserves all files (e.g. `dist/`, `scripts/`).

---

## 1. Build and create ZIP (on your PC)

```cmd
cd dfs-optimizer
.\deploy.bat
```

This produces **ionos-deploy.zip** in the project root (all files + folders inside, no root folder in the archive).

---

## 2. IONOS WebHosting panel

Open: **https://my.ionos.com/webhosting/b300099b-8c82-46cc-9e4b-250f6f70609b**

- Go to **File Management** (or **FTP / File Manager**).
- Navigate to **document root** (e.g. `htdocs/` or `/`).

---

## 3. Upload the ZIP

- Click **Upload**.
- Select **ionos-deploy.zip** (from your `dfs-optimizer` folder).
- Wait until the upload finishes.

---

## 4. Extract on the server

- In File Management, **right-click** `ionos-deploy.zip`.
- Choose **Extract** / **Extract Here** (or "Unzip here").
- Confirm. You should see **20+ files and folders**, including:
  - `index.html`
  - `assets/` (with JS/CSS)
  - `dist/` (if present)
  - `scripts/`
  - `cron-generate.py`
  - `.htaccess`
  - `package.json`
  - etc.

---

## 5. Optional: remove the ZIP

- Right-click `ionos-deploy.zip` -> **Delete** (to save space).
  Your site runs from the extracted files, not the zip.

---

## 6. Cron job

- In the IONOS panel go to **Cron Jobs**.
- **Add** a new cron job.
- **Command:**

```bash
0 6,7,11,12,16,17,22,23 * * * cd /homepages/htdocs && python3 cron-generate.py >> cron.log 2>&1
```

- Save.
  (Runs at 7AM, Noon, 6PM, 2AM ET.)

---

## 7. .htpasswd (if not already done)

- Generate locally:
  `python ionos-deploy/htpasswd-generate.py`
  (or `htpasswd -cb .htpasswd dfs-opt YourPassword123`)
- Upload the generated **.htpasswd** into the same directory as **.htaccess** (document root).

---

## 8. Test

- **URL:** https://gamesmoviesmusic.com
- **Username:** `dfs-opt`
- **Password:** [your .htpasswd password]

You should get the login prompt, then the Props Kelly Dashboard.

---

## 9. Verify on server (optional)

If you have SSH or "Execute script":

```bash
cd /homepages/htdocs   # or your document root
python3 verify.py
```

This checks that key files and folders exist and prints OK/missing.
